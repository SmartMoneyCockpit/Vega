== Vega Add‑On: IBKR HTTP Bridge Helper (for C:\IBC) ==

What this adds:
  • Start_Bridge_8888.bat   -> one‑click HTTP bridge on port 8888 
  • Test_Bridge.ps1         -> quick health checks local+public
  • Bridge_Service.xml      -> optional Scheduled Task (runs at logon)
  • BRIDGE_ENV_example.cmd  -> env vars template

Prereqs:
  • Python 3.10+ installed and on PATH
  • TWS or IB Gateway running (API enabled), e.g. via IBC StartTWS.bat
  • Open Windows Firewall for inbound TCP 8888 (or change PORT in .bat)

Usage (once):
  1) Edit BRIDGE_ENV_example.cmd -> set your IB_BRIDGE_API_KEY
  2) Double‑click Start_Bridge_8888.bat  (or run from PowerShell)
  3) Run Test_Bridge.ps1 to verify local and public /health

Render app settings:
  IBKR_BRIDGE_URL = http://<VPS_PUBLIC_IP>:8888
  IB_BRIDGE_API_KEY = <same key as in BRIDGE_ENV_example.cmd>

Optional Scheduled Task:
  • Import Bridge_Service.xml into Task Scheduler
  • Adjust paths to your C:\IBC\addons\bridge\Start_Bridge_8888.bat
