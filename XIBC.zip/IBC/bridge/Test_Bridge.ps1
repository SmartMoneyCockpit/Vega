
$ErrorActionPreference = "Stop"
function Test-Url($u){ try { (Invoke-WebRequest -UseBasicParsing -TimeoutSec 5 -Uri $u).StatusCode } catch { $_.Exception.Message } }
$local = "http://127.0.0.1:8888/health"
Write-Host "Local  : $local -> " (Test-Url $local)
$pub = Read-Host "Enter your public IP (e.g., 93.127.136.159)"
$remote = "http://$pub:8888/health"
Write-Host "Public : $remote -> " (Test-Url $remote)
