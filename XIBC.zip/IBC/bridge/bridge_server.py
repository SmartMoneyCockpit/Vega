from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import PlainTextResponse, JSONResponse
from ib_insync import IB, Stock, util, MarketOrder
import os, asyncio

app = FastAPI(title="VegaBridge", version="0.2.0")

ib = IB()
_connect_lock = asyncio.Lock()

async def ensure_connected():
    if ib.isConnected():
        return
    async with _connect_lock:
        if not ib.isConnected():
            host = os.getenv("IB_HOST", "127.0.0.1")
            port = int(os.getenv("IB_PORT", "7496"))  # 7497 if paper
            cid  = int(os.getenv("IB_CLIENT_ID", "1"))
            await ib.connectAsync(host, port, clientId=cid, timeout=6.0)

def _check_key(req: Request):
    expected = os.getenv("IB_BRIDGE_API_KEY", "")
    got = req.headers.get("x-api-key", "")
    if expected and got != expected:
        raise HTTPException(status_code=401, detail="Invalid API key")

@app.get("/health", response_class=PlainTextResponse)
async def health():
    try:
        await ensure_connected()
        return "ok"
    except Exception as e:
        return PlainTextResponse(f"not ok: {e}", status_code=503)

async def _get_realtime_or_fallback(sym: str) -> dict:
    """Try realtime first; if not available, fallback to latest daily close."""
    await ensure_connected()
    c = Stock(sym, "SMART", "USD")
    # --- Try realtime ---
    try:
        tks = await ib.reqTickersAsync(c, timeout=6.0)
        tk = tks[0] if tks else None
    except Exception as e:
        # Bubble a clear IB error
        return {"error": "ibkr_request_failed", "message": str(e)}

    last = bid = ask = close = None
    time_ = None
    if tk:
        last  = tk.last
        bid   = tk.bid
        ask   = tk.ask
        close = tk.close
        time_ = util.formatIBDatetime(tk.time) if tk.time else None

    # If we have a usable price, return realtime
    mid = None
    if bid and ask and bid > 0 and ask > 0:
        mid = (bid + ask) / 2.0
    price = last or mid or close

    if price:
        return {
            "symbol": sym,
            "price": price,
            "last": last, "bid": bid, "ask": ask, "mid": mid, "close": close,
            "source": "realtime", "time": time_
        }

    # --- Fallback: latest daily close ---
    try:
        bars = await ib.reqHistoricalDataAsync(
            c, endDateTime="", durationStr="1 D",
            barSizeSetting="1 day", whatToShow="TRADES",
            useRTH=False, formatDate=1, timeout=6.0
        )
        if bars:
            bar = bars[-1]
            return {
                "symbol": sym,
                "price": bar.close,
                "last": None, "bid": None, "ask": None, "mid": None, "close": bar.close,
                "source": "daily_close_fallback",
                "time": str(bar.date)
            }
        else:
            return {"error": "no_price_data", "message": "No realtime or historical data returned."}
    except Exception as e:
        return {"error": "historical_request_failed", "message": str(e)}

@app.get("/price/{symbol}")
async def price(symbol: str, request: Request):
    _check_key(request)
    sym = symbol.upper().strip()
    try:
        data = await _get_realtime_or_fallback(sym)
        if "error" in data:
            return JSONResponse(status_code=502, content=data)
        return data
    except Exception as e:
        # last-resort safeguard with explicit error
        return JSONResponse(status_code=500, content={"error": "unhandled", "message": str(e)})

@app.post("/order/market")
async def market_order(symbol: str, action: str = "BUY", qty: int = 1, request: Request = None):
    _check_key(request)
    await ensure_connected()
    action = action.upper().strip()
    if action not in ("BUY", "SELL"):
        raise HTTPException(status_code=400, detail="action must be BUY or SELL")
    c = Stock(symbol.upper().strip(), "SMART", "USD")
    order = MarketOrder(action, qty)
    trade = await ib.placeOrderAsync(c, order)
    return {
        "symbol": symbol.upper(), "action": action, "qty": qty,
        "orderId": trade.order.orderId, "status": trade.orderStatus.status
    }
ib=IB()
async def ensure():
    host=os.getenv("IB_HOST","127.0.0.1");port=int(os.getenv("IB_PORT","7496"));cid=int(os.getenv("IB_CLIENT_ID","1"))
    if not ib.isConnected():
        await ib.connectAsync(host,port,clientId=cid,timeout=4.0)
@app.get("/health")
async def health():
    try:
        await ensure();return PlainTextResponse("ok")
    except Exception as e:
        return PlainTextResponse(f"not ok: {e}", status_code=503)
@app.get("/price/{sym}")
async def price(sym:str, request:Request):
    key=os.getenv("IB_BRIDGE_API_KEY","");hdr=request.headers.get("x-api-key","")
    if key and hdr!=key: raise HTTPException(status_code=401, detail="bad key")
    await ensure();c=Stock(sym.upper(),"SMART","USD");t=(await ib.reqTickersAsync(c,timeout=4.0))[0]
    mid=(t.bid+t.ask)/2.0 if t.bid and t.ask else None;last=t.last or mid or t.close
    return {"symbol":sym.upper(),"last":last,"bid":t.bid,"ask":t.ask,"mid":mid,"close":t.close,"time":(util.formatIBDatetime(t.time) if t.time else None)}
@app.post("/order/market")
async def mkt(symbol:str,action:str="BUY",qty:int=1,request:Request=None):
    key=os.getenv("IB_BRIDGE_API_KEY","");hdr=request.headers.get("x-api-key","")
    if key and hdr!=key: raise HTTPException(status_code=401, detail="bad key")
    await ensure();c=Stock(symbol.upper(),"SMART","USD");o=MarketOrder(action.upper(),qty);tr=await ib.placeOrderAsync(c,o)
    return {"orderId":tr.order.orderId,"status":tr.orderStatus.status}
ib=IB()
async def ensure():
    host=os.getenv("IB_HOST","127.0.0.1");port=int(os.getenv("IB_PORT","7496"));cid=int(os.getenv("IB_CLIENT_ID","1"))
    if not ib.isConnected():
        await ib.connectAsync(host,port,clientId=cid,timeout=4.0)
@app.get("/health")
async def health():
    try:
        await ensure();return PlainTextResponse("ok")
    except Exception as e:
        return PlainTextResponse(f"not ok: {e}", status_code=503)
@app.get("/price/{sym}")
async def price(sym:str, request:Request):
    key=os.getenv("IB_BRIDGE_API_KEY","");hdr=request.headers.get("x-api-key","")
    if key and hdr!=key: raise HTTPException(status_code=401, detail="bad key")
    await ensure();c=Stock(sym.upper(),"SMART","USD");t=(await ib.reqTickersAsync(c,timeout=4.0))[0]
    mid=(t.bid+t.ask)/2.0 if t.bid and t.ask else None;last=t.last or mid or t.close
    return {"symbol":sym.upper(),"last":last,"bid":t.bid,"ask":t.ask,"mid":mid,"close":t.close,"time":(util.formatIBDatetime(t.time) if t.time else None)}
@app.post("/order/market")
async def mkt(symbol:str,action:str="BUY",qty:int=1,request:Request=None):
    key=os.getenv("IB_BRIDGE_API_KEY","");hdr=request.headers.get("x-api-key","")
    if key and hdr!=key: raise HTTPException(status_code=401, detail="bad key")
    await ensure();c=Stock(symbol.upper(),"SMART","USD");o=MarketOrder(action.upper(),qty);tr=await ib.placeOrderAsync(c,o)
    return {"orderId":tr.order.orderId,"status":tr.orderStatus.status}
ib=IB()
async def ensure():
    host=os.getenv("IB_HOST","127.0.0.1");port=int(os.getenv("IB_PORT","7496"));cid=int(os.getenv("IB_CLIENT_ID","1"))
    if not ib.isConnected():
        await ib.connectAsync(host,port,clientId=cid,timeout=4.0)
@app.get("/health")
async def health():
    try:
        await ensure();return PlainTextResponse("ok")
    except Exception as e:
        return PlainTextResponse(f"not ok: {e}", status_code=503)
@app.get("/price/{sym}")
async def price(sym:str, request:Request):
    key=os.getenv("IB_BRIDGE_API_KEY","");hdr=request.headers.get("x-api-key","")
    if key and hdr!=key: raise HTTPException(status_code=401, detail="bad key")
    await ensure();c=Stock(sym.upper(),"SMART","USD");t=(await ib.reqTickersAsync(c,timeout=4.0))[0]
    mid=(t.bid+t.ask)/2.0 if t.bid and t.ask else None;last=t.last or mid or t.close
    return {"symbol":sym.upper(),"last":last,"bid":t.bid,"ask":t.ask,"mid":mid,"close":t.close,"time":(util.formatIBDatetime(t.time) if t.time else None)}
@app.post("/order/market")
async def mkt(symbol:str,action:str="BUY",qty:int=1,request:Request=None):
    key=os.getenv("IB_BRIDGE_API_KEY","");hdr=request.headers.get("x-api-key","")
    if key and hdr!=key: raise HTTPException(status_code=401, detail="bad key")
    await ensure();c=Stock(symbol.upper(),"SMART","USD");o=MarketOrder(action.upper(),qty);tr=await ib.placeOrderAsync(c,o)
    return {"orderId":tr.order.orderId,"status":tr.orderStatus.status}
