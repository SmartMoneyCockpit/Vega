# Watchdog for IBC/TWS
# Writes to C:\IBC\watchdog.log and restarts IBC if API port 7497 is down.

$port = 7497
$log  = "C:\IBC\watchdog.log"
$ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

try {
    # Quick TCP check (2s timeout)
    $client = New-Object System.Net.Sockets.TcpClient
    $iar    = $client.BeginConnect('127.0.0.1', $port, $null, $null)
    $ok     = $iar.AsyncWaitHandle.WaitOne(2000, $false) -and $client.Connected
    $client.Close()

    if ($ok) {
        Add-Content -Path $log -Value "$ts - Port $port OK"
    } else {
        Add-Content -Path $log -Value "$ts - Port $port unreachable, restarting IBC..."
        Start-Process -FilePath "C:\IBC\starter.bat" -ArgumentList "/INLINE" -WorkingDirectory "C:\IBC"
    }
}
catch {
    Add-Content -Path $log -Value "$ts - ERROR: $($_.Exception.Message)"
}
