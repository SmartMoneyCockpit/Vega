IBC Starter Pack
================

Files included:
- IBC.ini (with your IBKR username and password)
- Start-IBC.bat (launches IBC with auto-login)
- README-IBC.txt (instructions)

Security Warning:
-----------------
Your credentials are in IBC.ini in plain text. 
Keep this folder private and restrict access.