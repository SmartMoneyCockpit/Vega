import streamlit as st

def render():
    st.header('APAC Dashboard')
    st.write('Nikkei 225, ASX 200, CSI 300, Hang Seng. (IBKR snapshots once configured)')
