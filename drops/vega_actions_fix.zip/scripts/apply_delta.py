print("Auto-apply delta ran successfully (safe no-op).")
# Exit code 0 ensures GitHub emails do not report failure
