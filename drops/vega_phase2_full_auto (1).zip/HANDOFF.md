# Handoff — Phase 2 (Full Auto)

- Push to GitHub, deploy on Render.
- Start: `streamlit run app.py --server.port $PORT --server.address 0.0.0.0`
- Actions schedule builds caches + PDF each weekday. See artifacts in GitHub → Actions → vega-vault.
