import streamlit as st, os, glob

def render():
    st.header("Auto-Journal")
    st.write("Daily journal files appear here when the Action runs.")
    files = sorted(glob.glob("vault/journal/journal-*.txt"))
    if files:
        st.success(f"Latest: {os.path.basename(files[-1])}")
        with open(files[-1], "r", encoding="utf-8") as f:
            st.text(f.read())
    else:
        st.info("No journal files yet. The GitHub Action will create them automatically.")
