import streamlit as st
def render():
    st.header("APAC ETF Dashboard")
    st.write("Nikkei 225, ASX 200, CSI 300, Hang Seng indices (embeds to be swapped to IBKR charts later).")
