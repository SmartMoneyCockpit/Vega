import streamlit as st
def render():
    st.header("Global Risk Heatmap")
    st.write("Overlay of volatility, FX, and geopolitics. (Stub)")
