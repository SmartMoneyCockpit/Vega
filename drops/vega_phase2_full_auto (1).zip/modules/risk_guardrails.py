# Server-side only (guardrails JSON in /vault/cache).
