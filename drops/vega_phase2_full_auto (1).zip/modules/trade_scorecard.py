import streamlit as st
import pandas as pd

def render():
    st.header("AI Trade Quality Scorecard")
    st.caption("Grades: entry logic, macro alignment, risk, discipline.")
    df = pd.DataFrame([
        {"Ticker":"SPY","Grade":"B+","Notes":"RS neutral; breadth mixed; wait for pullback"},
        {"Ticker":"SQQQ","Grade":"A-","Notes":"Risk-off confirmed; hedge candidate"},
    ])
    st.dataframe(df, use_container_width=True)
