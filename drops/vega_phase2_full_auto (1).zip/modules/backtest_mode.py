import streamlit as st
def render():
    st.header("Backtest Mode")
    st.write("Simulate strategies without touching the live journal (server-enforced).")
    st.toggle("Enable Backtest Mode", value=False, key="backtest_mode")
