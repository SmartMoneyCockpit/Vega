import streamlit as st
import pandas as pd
from datetime import datetime
import os, json

def _load_cache(name):
    path = os.path.join("vault","cache",name)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def render():
    st.header("Market Breadth Dashboard")
    colA, colB, colC = st.columns(3)
    with colA:
        st.metric("Advancers", _load_cache("breadth_adv.json").get("value", "—"))
    with colB:
        st.metric("Decliners", _load_cache("breadth_dec.json").get("value", "—"))
    with colC:
        st.metric("New Highs / Lows", _load_cache("breadth_hilo.json").get("value", "—"))

    st.write("**Sector Breadth**")
    df = pd.DataFrame(_load_cache("breadth_sector.json").get("rows", []), columns=["Sector","% Advancing","RS"])
    if df.empty:
        df = pd.DataFrame([["Technology", 52, 0.98],["Financials", 48, 0.92],["Energy", 55, 1.04]], columns=["Sector","% Advancing","RS"])
    st.dataframe(df, use_container_width=True)

    st.markdown("---")
    st.subheader("Snapshot Export")
    st.caption("PDF/PNG is created by the server workflow and saved to /vault/snapshots automatically each morning.")
