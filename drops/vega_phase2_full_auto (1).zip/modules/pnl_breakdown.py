import streamlit as st
import pandas as pd

def render():
    st.header("PnL & Risk Breakdown")
    sample = pd.DataFrame([
        {"Strategy":"Swing","PnL($)": 420, "Risk($)": 140, "RR": 3.0},
        {"Strategy":"Hedge","PnL($)": -75, "Risk($)": 50, "RR": -1.5},
    ])
    st.dataframe(sample, use_container_width=True)
