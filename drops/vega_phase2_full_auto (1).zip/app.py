import streamlit as st
from datetime import datetime, timezone

st.set_page_config(page_title="Vega Cockpit", layout="wide")

# Sidebar
st.sidebar.title("Vega Cockpit — Phase 2 (Auto)")
st.sidebar.caption("IBKR Connection: ready (stub) — TradingView references removed")
section = st.sidebar.radio(
    "Dashboards / Tools",
    [
        "Breadth Panel",
        "Global Risk Heatmap",
        "ETF Tactical",
        "VectorVest Screeners",
        "PnL & Risk Breakdown",
        "AI Trade Scorecard",
        "Backtest Mode",
        "Health / Journal",
        "BoJ Rate Hike Playbook",
        "APAC Dashboard"
    ],
    index=0
)

# Import panels
from modules.breadth_panel import render as breadth_render
from modules.risk_heatmap import render as heatmap_render
from modules.pnl_breakdown import render as pnl_render
from modules.trade_scorecard import render as scorecard_render
from modules.backtest_mode import render as backtest_render
from modules.journal_auto import render as journal_render
from modules.boj_playbook import render as boj_render
from modules.apac_dashboard import render as apac_render

def etf_tactical_panel():
    st.header("ETF Tactical Dashboard (Auto-fed)")
    st.write("This panel reads cached signals from `/vault/cache/vectorvest_signals.json`.")
    st.code('''push -> Actions -> cache -> cockpit reads /vault/cache/*.json''')

def vectorvest_panel():
    st.header("VectorVest Screeners (Auto-fed)")
    st.write("Precomputed screener outputs are loaded from /vault/cache/.")

# Router
if section == "Breadth Panel":
    breadth_render()
elif section == "Global Risk Heatmap":
    heatmap_render()
elif section == "ETF Tactical":
    etf_tactical_panel()
elif section == "VectorVest Screeners":
    vectorvest_panel()
elif section == "PnL & Risk Breakdown":
    pnl_render()
elif section == "AI Trade Scorecard":
    scorecard_render()
elif section == "Backtest Mode":
    backtest_render()
elif section == "Health / Journal":
    journal_render()
elif section == "BoJ Rate Hike Playbook":
    boj_render()
elif section == "APAC Dashboard":
    apac_render()

st.sidebar.markdown("---")
st.sidebar.caption(f"Build: Phase 2 • {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")
