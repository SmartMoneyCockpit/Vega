import os, time
base = os.path.join("vault","journal")
os.makedirs(base, exist_ok=True)
ts = time.strftime("%Y-%m-%d")
path = os.path.join(base, f"journal-{ts}.txt")
with open(path, "w", encoding="utf-8") as f:
  f.write(f"Vega Auto-Journal — {ts}\n")
  f.write("Summary: trades, notes, health markers (stub)\n")
print("Journal stub emitted:", path)
