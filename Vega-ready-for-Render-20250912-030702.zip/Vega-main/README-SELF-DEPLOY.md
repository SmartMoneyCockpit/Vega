# Vega Cockpit — Self-Deployment (Render)
Date: 2025-09-12

This repo contains a one-click Render blueprint and CI sanity check.
See `UPGRADE_NOTES.md` for quick steps.
