## Weekly Module Update — Week 4
**Planned:** PDF Report Generator v1.0 + Render Deploy Pipeline

**What you’ll get**
- PDF exporter for Morning/Weekly reports
- Render-compatible deploy script & health checks
- Secrets & environment doc
