## Weekly Module Update — Week 3
**Planned:** Backtesting & Journal Automation v1.0

**What you’ll get**
- Backtest mode toggle + isolation of journal entries
- Auto-Journal Generator (summary of the day’s trades)
- Export-to-CSV/PDF hooks
