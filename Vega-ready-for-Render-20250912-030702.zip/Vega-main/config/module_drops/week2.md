## Weekly Module Update — Week 2
**Planned:** Risk & Metrics Module v1.0, Cockpit KPIs

**What you’ll get**
- Portfolio heat & open-risk dashboard
- Weekly scorecard (win rate, expectancy, process score)
- KPI table component for the cockpit

**Action**
- I’ll provide the code blocks to paste (same flow as Week 1).
