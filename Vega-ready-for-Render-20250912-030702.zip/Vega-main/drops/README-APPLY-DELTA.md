See .github/workflows/auto-apply-delta.yml and apply_delta.py
