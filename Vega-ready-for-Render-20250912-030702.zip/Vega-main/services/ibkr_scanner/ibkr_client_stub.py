# Safe IBKR client stub — replace with live ib_insync wiring when gateway is ready.
try:
    from ib_insync import IB, Stock, util  # Optional, may not be installed in Render
except Exception:
    IB = None

class IBKRClient:
    def __init__(self, host: str = "127.0.0.1", port: int = 7497, client_id: int = 111):
        self.host, self.port, self.client_id = host, port, client_id
        self._ib = None

    def connect(self):
        if IB is None:
            return False, "ib_insync not available"
        self._ib = IB()
        try:
            self._ib.connect(self.host, self.port, clientId=self.client_id, readonly=True)
            return True, "connected"
        except Exception as e:
            return False, str(e)

    def disconnect(self):
        if self._ib:
            try:
                self._ib.disconnect()
            except Exception:
                pass

    def scan_example(self, symbols=None):
        # Placeholder scan that returns a static structure
        symbols = symbols or ["AAPL", "MSFT", "SPY"]
        return [{"symbol": s, "signal": "neutral", "note": "stub"} for s in symbols]
