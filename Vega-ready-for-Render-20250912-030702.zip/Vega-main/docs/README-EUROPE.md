# Europe Trading Module

Streamlit page at `pages/Europe_Trading.py` reading config from `config/markets/europe.yaml`.
Connect your data layer to populate prices, breadth, IV, and earnings windows.
