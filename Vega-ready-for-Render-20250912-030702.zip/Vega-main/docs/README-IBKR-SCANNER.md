# IBKR Scanner (Stub)

This page is safe to run without `ib_insync` or a live IBKR Gateway. It shows the UI wiring and a placeholder scan.
**Upgrade path**: swap `services/ibkr_scanner/ibkr_client_stub.py` with a real client using `ib_insync`.
