
import streamlit as st
def main():
    st.header("Pdf Report.Py Page")
    st.image("static/assets/animal_2.jpg", width=120)
    st.success("✅ Pdf Report.Py is loaded and ready.")

# 🧠