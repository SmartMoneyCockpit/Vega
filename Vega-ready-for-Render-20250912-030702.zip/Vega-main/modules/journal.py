
import streamlit as st
def main():
    st.header("Journal.Py Page")
    st.image("static/assets/animal_2.jpg", width=120)
    st.success("✅ Journal.Py is loaded and ready.")

# 🧠