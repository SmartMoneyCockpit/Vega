import streamlit as st
def render(): st.header('PnL & Risk Breakdown')
