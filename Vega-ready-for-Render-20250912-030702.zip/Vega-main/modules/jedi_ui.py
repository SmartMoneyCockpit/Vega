
import streamlit as st
def main():
    st.header("Jedi Ui.Py Page")
    st.image("static/assets/animal_2.jpg", width=120)
    st.success("✅ Jedi Ui.Py is loaded and ready.")

# 🧠