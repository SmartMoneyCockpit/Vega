
import streamlit as st
def main():
    st.header("Fx Exposure.Py Page")
    st.image("static/assets/animal_2.jpg", width=120)
    st.success("✅ Fx Exposure.Py is loaded and ready.")

# 🧠