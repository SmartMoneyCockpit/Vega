
import streamlit as st
def main():
    st.header("Training.Py Page")
    st.image("static/assets/animal_2.jpg", width=120)
    st.success("✅ Training.Py is loaded and ready.")

# 🧠