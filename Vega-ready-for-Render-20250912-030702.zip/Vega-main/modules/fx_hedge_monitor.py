
import streamlit as st
def main():
    st.header("Fx Hedge Monitor.Py Page")
    st.image("static/assets/animal_2.jpg", width=120)
    st.success("✅ Fx Hedge Monitor.Py is loaded and ready.")

# 🧠