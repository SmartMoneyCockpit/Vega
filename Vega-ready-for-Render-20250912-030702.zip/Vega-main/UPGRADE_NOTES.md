# UPGRADE_NOTES — Vega Cockpit Hands-Off Upgrade
Date: 2025-09-12 02:46:38

## Added (Non-breaking)
- Render blueprint (`render.yaml`), CI workflow, and `.env.example`
- `pages/IBKR_Scanner.py` with `services/ibkr_scanner/ibkr_client_stub.py` (safe without ib_insync)
- `pages/Europe_Trading.py` + `config/markets/europe.yaml`
- Docs: `README-SELF-DEPLOY.md`, `docs/README-IBKR-SCANNER.md`, `docs/README-EUROPE.md`
- `scripts/deploy_render.sh`

## Notes
- IBKR scanner is a **stub** to avoid deployment crashes. When ready, replace the stub with a live `ib_insync` client.
- Europe Trading is config-driven and ready to connect to your data layer.
- No destructive edits were made to your app code.

## Deploy
1. Push to GitHub.
2. In Render: Build=`pip install -r requirements.txt`; Start=`streamlit run app.py --server.port $PORT --server.address 0.0.0.0`.
3. Add `.env.example` values in Render.
