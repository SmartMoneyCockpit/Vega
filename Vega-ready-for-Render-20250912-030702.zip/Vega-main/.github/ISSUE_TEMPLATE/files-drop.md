---
name: Files Drop
about: Paste one or many files; the workflow writes them to the repo
title: "Files Drop: <SHORT DESCRIPTION>"
labels: ["files-drop"]
---

Paste blocks like this (one per file):

```file:config/vega/settings.na.yaml
<your YAML here>
