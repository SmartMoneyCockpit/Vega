import streamlit as st
import pandas as pd
from pathlib import Path
import json

st.set_page_config(page_title="Europe Trading", layout="wide")

st.title("🌍 Europe Trading — Vega Cockpit")
st.caption("Indices, ETFs, FX overlays, and quick relative-strength snapshot.")

cfg_path = Path("config/markets/europe.yaml")
if not cfg_path.exists():
    st.error("Missing config: config/markets/europe.yaml")
else:
    st.success("Europe config loaded.")

st.subheader("Quick Filters")
col1, col2, col3 = st.columns(3)
with col1:
    risk = st.selectbox("Risk Regime (manual)", ["Neutral", "Risk-On", "Risk-Off"], index=0)
with col2:
    earnings_window = st.checkbox("Hide names within 30 days of earnings", value=True)
with col3:
    show_fx = st.checkbox("Show FX overlays", value=True)

st.info("This module is pre-wired to plug into your existing data clients. For now it renders config-driven watchlists and placeholders so the app never crashes.")

st.subheader("Starter Universe")
st.markdown("- **Indices**: FTSE 100 (^FTSE), DAX (^GDAXI), CAC 40 (^FCHI), Euro Stoxx 50 (^STOXX50E)")
st.markdown("- **ETFs**: VGK, FEZ, EZU, IEUR, EWG, EWQ, DAX")
st.markdown("- **FX**: EURUSD, GBPUSD, USDCHF")
st.caption("Upgrade path: wire to your data layer for live prices, breadth, and options IV screens.")

st.subheader("Next Steps (Upgrade-Ready)")
st.write("""
- Connect to your data feeds (Sheets/Polygon/IBKR/TradingView).
- Add RS/breadth matrices vs SPY/NDX and sector ETFs.
- Enforce your standing rules: no buys <30d of earnings; R/R ≥ 1:3; contras only in risk-off.
- Add morning (EU) and midday handoff reports.
""")
