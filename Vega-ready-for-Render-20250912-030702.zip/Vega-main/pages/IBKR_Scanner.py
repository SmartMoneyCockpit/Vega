import os
import streamlit as st
from services.ibkr_scanner.ibkr_client_stub import IBKRClient

st.set_page_config(page_title="IBKR Scanner", layout="wide")
st.title("🔎 IBKR Stock Scanner (Stub)")

host = os.getenv("IBKR_HOST", "127.0.0.1")
port = int(os.getenv("IBKR_PORT", "7497"))
client_id = int(os.getenv("IBKR_CLIENT_ID", "111"))

with st.sidebar:
    st.subheader("Connection")
    st.write(f"Host: {host}  Port: {port}  ClientId: {client_id}")
    if st.button("Test Connect (safe)"):
        ok, msg = IBKRClient(host, port, client_id).connect()
        st.write("Result:", ok, msg)

st.info("This is a **safe stub**. It will not crash even without ib_insync or IB Gateway. When you're ready, we switch to the live client and real scanners.")

client = IBKRClient(host, port, client_id)
results = client.scan_example(["AAPL", "MSFT", "SPY"])
st.subheader("Sample Scan Results")
st.dataframe(results)
