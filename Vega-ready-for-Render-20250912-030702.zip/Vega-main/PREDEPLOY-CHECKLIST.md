# PREDEPLOY CHECKLIST — Vega Cockpit (Render)
Generated: 2025-09-12 03:07:02

## Files verified
- render.yaml
- .env.example
- .github/workflows/render-deploy.yml
- scripts/deploy_render.sh
- pages/Europe_Trading.py
- config/markets/europe.yaml
- pages/IBKR_Scanner.py
- services/ibkr_scanner/ibkr_client_stub.py
- .streamlit/config.toml
- requirements.txt (has: streamlit, pandas, numpy)

## Issues
None detected.

## Render Setup
Build: `pip install -r requirements.txt`
Start: `streamlit run app.py --server.port $PORT --server.address 0.0.0.0`

## Environment (Render → Environment)
- ENVIRONMENT=production
- TZ=America/Los_Angeles
- IBKR_HOST=127.0.0.1
- IBKR_PORT=7497
- IBKR_CLIENT_ID=111
- (optional) SENDGRID_API_KEY

## Notes
- IBKR scanner is a safe stub. Live wiring will arrive in your next weekly upgrade.
- Europe Trading module is config-driven and ready to hook to your data clients.
