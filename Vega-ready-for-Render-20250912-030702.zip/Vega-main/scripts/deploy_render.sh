#!/usr/bin/env bash
set -euo pipefail
PORT="${PORT:-8501}"
echo "Using PORT=$PORT"
if [ -f requirements.txt ]; then
  echo "Installing dependencies from requirements.txt ..."
  pip install -r requirements.txt
fi
exec streamlit run app.py --server.port "$PORT" --server.address 0.0.0.0
